package wb.lp.peihuo;

import static wb.lp.peihuo.HTTPUtils.BASE_URL;

import android.content.Intent;
import android.os.Build;
import android.os.Bundle;
import android.util.Log;
import android.widget.ListView;

import androidx.activity.EdgeToEdge;
import androidx.annotation.Nullable;
import androidx.annotation.RequiresApi;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.TypeReference;

import java.io.IOException;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;
import java.util.Map;
import java.util.Objects;
import java.util.function.BiConsumer;
import java.util.stream.Collectors;

import okhttp3.OkHttpClient;
import okhttp3.Request;
import okhttp3.Response;
import wb.lp.peihuo.adapter.MyAdapter;
import wb.lp.peihuo.data.AllItem;

public class MainActivity extends AppCompatActivity {

//    int requestCode = 1;

    public static final String SY = "三爻";
    public static final String YH = "樱花";
    public static final String WD = "万达";
    public static final String XQG = "兴庆宫";
    public static final String HT = "海天";
    public static final String LM = "联盟";
    public static final String QB = "青北";
    public static final String JH = "金辉";
    public static final String QJ = "曲江";


    @RequiresApi(api = Build.VERSION_CODES.N)
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

//        getWindow().addFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN);
//        getWindow().clearFlags();
        Objects.requireNonNull(getSupportActionBar()).hide();

        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_main);
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });
//
//        Intent intent = getIntent();
//        String ysdata = intent.getStringExtra("map");
////        Gson gson = new Gson();
////        map = gson.fromJson(ysdata, Map<String,AllItem>);
//        map  = JSON.parseObject(ysdata, new TypeReference<Map<String, AllItem>>(){});
////        this.allCount = intent.getIntExtra("allCount", 0);
//
//        loadData();

        Intent intent = getIntent();
        String surl = intent.getStringExtra("surl");

//        try {
//            loadData(strings);
//        } catch (Exception e) {
//            MainActivity.this.finish();
//            Toast.makeText(MainActivity.this, "配货数据格式不正确", Toast.LENGTH_LONG).show();
//        }

        new Thread(new Runnable() {
            @Override
            public void run() {
                OkHttpClient client = new OkHttpClient();
                Request request = new Request.Builder().url(BASE_URL + surl).build();
                try {
                    Response execute = client.newCall(request).execute();
                    String json = execute.body().string();
                    map = JSON.parseObject(json, new TypeReference<Map<String, AllItem>>() {
                    });


                    ArrayList<AllItem> objects = new ArrayList<>();
                    map.forEach(new BiConsumer<String, AllItem>() {
                        @Override
                        public void accept(String s, AllItem aDouble) {
                            objects.add(aDouble);
                        }
                    });
                    List<AllItem> collect = objects.stream().sorted(new Comparator<AllItem>() {
                        @Override
                        public int compare(AllItem o1, AllItem o2) {
                            return o2.getWeight() - o1.getWeight();
                        }
                    }).collect(Collectors.toList());

                    runOnUiThread(new Runnable() {
                        @Override
                        public void run() {
                            showView(collect);
                        }
                    });

                } catch (IOException e) {
                    throw new RuntimeException(e);
                }
            }
        }).start();

    }

    //    double allCount;
    private Map<String, AllItem> map;

    @RequiresApi(api = Build.VERSION_CODES.N)
//    private void loadData(List<String> strings) throws Exception {
//    private void loadData()  {
//
////        double allCount = 0;
//
////        String md = null;
//
////
////        //给每个记录加上门店信息
////        List<Item> items = new ArrayList<>();
////        for (String string : strings) {
////            if (switchData(string)) {
////
//////                Log.d("LP", "loadData: " + string);
////
////                String[] split = string.split("\t");
////                Item item = new Item();
////                item.setMendian(md);
////                if (split.length != 3) {
////                    item.setName(split[0] + split[1]);
////                } else {
////                    item.setName(split[0]);
////                }
////
////                item.setDanwei(split[split.length-2]);
////                item.setCount(Double.parseDouble(split[split.length-1]));
////                items.add(item);
////
////                allCount += item.getCount();
////
////            } else {
////                md = string;
////            }
////        }
//
//
//        //核心数据
//
////        items.forEach(i -> {
////            String name = i.getName();
////            boolean b = map.containsKey(name);
////
////            if (b) {
////                AllItem allItem = map.get(name);
////                allItem.setCount(allItem.getCount() + i.getCount());
//////                map.put(name, allItem);
////            } else {
////                AllItem allItem = new AllItem(i.getName(), i.getDanwei(), i.getCount());
////                allItem.setRequestCode(requestCode++);
////                map.put(name, allItem);
////            }
////
////            SubItem subItem = new SubItem();
////            subItem.setMendian(i.getMendian());
////            subItem.setCount(i.getCount());
////            subItem.setDanwei(i.getDanwei());
////
////            AllItem allItemX = map.get(name);
////            allItemX.getSubItems().add(subItem);
////
////        });
//
//
//        //排序并展示
//
//        ArrayList<AllItem> objects = new ArrayList<>();
//        map.forEach(new BiConsumer<String, AllItem>() {
//            @Override
//            public void accept(String s, AllItem aDouble) {
//                objects.add(aDouble);
//            }
//        });
//        List<AllItem> collect = objects.stream().sorted(new Comparator<AllItem>() {
//            @Override
//            public int compare(AllItem o1, AllItem o2) {
//                return o2.getWeight() - o1.getWeight();
//            }
//        }).collect(Collectors.toList());
//
//        showView(collect);
//
////        Toast.makeText(MainActivity.this, "今日配货总数量：" + allCount, Toast.LENGTH_LONG).show();
//
//    }

    private boolean switchData(String str) {
        if (str.equals(SY)) return false;
        else if (str.equals(YH)) return false;
        else if (str.equals(WD)) return false;
        else if (str.equals(XQG)) return false;
        else if (str.equals(HT)) return false;
        else if (str.equals(LM)) return false;
        else if (str.equals(QB)) return false;
        else if (str.equals(JH)) return false;
        else if (str.equals(QJ)) return false;
        return true;
    }

//    private List<String> loadDataFromDisk() {
//        List<String> data = new ArrayList<>();
//        String[] split = S.split("\n");
//        for (String string : split) {
//            data.add(string);
//        }
//        return data;
//    }


    @Override
    protected void onActivityResult(int requestCode, int resultCode, @Nullable Intent data) {
        super.onActivityResult(requestCode, resultCode, data);

        String rmS = null;

        for (AllItem allItem : map.values()) {
            if (allItem.getRequestCode() == requestCode && resultCode == RESULT_OK) {
                rmS = allItem.getName();
                break;
            }
        }

//        for (String s : map.keySet()) {
//            Log.d("xxxxxx", s);
//
//            if (s.hashCode() == requestCode && resultCode == RESULT_OK) {
////                Toast.makeText(this, s, Toast.LENGTH_SHORT).show();
//                rmS = s;
//                break;
//            }
//
//        }

        if (rmS != null && rmS.length() > 0) {
//            map.remove(rmS);

            List<AllItem> datas = ((MyAdapter) ((ListView) findViewById(R.id.list_view)).getAdapter()).getObjects();
            int rmI = -1;
            for (int i = 0; i < datas.size(); i++) {
                AllItem allItem = datas.get(i);
                if (allItem.getName().equals(rmS)) {
                    rmI = i;
                    break;
                }
            }
            if (rmI != -1) {
                datas.remove(rmI);
                Log.d("xxxxxx", rmS);
            }

            showView(datas);
        }
    }

    private void showView(List data) {
        ListView listView = findViewById(R.id.list_view);
//        listView.setAdapter(new MyAdapter(this, android.R.layout.select_dialog_singlechoice, data));
//        listView.setAdapter(new MyAdapter(this, android.R.layout.simple_list_item_1, data));
        listView.setAdapter(new MyAdapter(this, R.layout.main_choice, data));

//        listView.setOnItemClickListener(new AdapterView.OnItemClickListener() {
//            @Override
//            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
////                List<SubItem> subItems = ((AllItem) data.get(position)).getSubItems();
////                Toast.makeText(MainActivity.this, subItems.toString(), Toast.LENGTH_SHORT).show();
//
//                Intent intent = new Intent();
//                intent.setClass(MainActivity.this, SubActivity.class);
//                Gson gson = new Gson();
//                String json = gson.toJson(data.get(position));
//                intent.putExtra("data", json);
//
//                startActivity(intent);
//            }
//        });
    }


//    public static String S = "樱花\n" + "白糖\t袋\t1\n" + "包子辣油\t桶\t1.0\n" + "酸鱼汤底\t包\t2\n" + "五仁酱丁\t箱\t1\n" + "天缘醋\t桶\t1.0\n" + "抽纸（餐巾纸）\t件\t1\n" + "肥牛卷\t盒\t2\n" + "750打包盒\t件\t3\n" + "1250打包盒\t件\t2\n" + "口杯袋\t把\t5\n" + "17背心袋\t把\t20\n" + "26背心袋\t把\t10\n" + "虾米\t袋\t1\n" + "擀面皮辣油\t桶\t2.0\n" + "小米南瓜粥\t份\t6\n" + "红豆玉米粥\t份\t10\n" + "八宝粥\t份\t12\n" + "凉皮调料水\t桶\t1.0\n" + "鸡架料包\t袋\t1\n" + "青椒南瓜馅\t袋\t3\n" + "鸡蛋粉条\t袋\t3\n" + "馄饨馅\t袋\t5\n" + "鲜肉馅\t袋\t10\n" + "鸡精组合\t份\t1\n" + "酱肉馅\t份\t2\n" + "发面料\t袋\t1\n" + "金辉\n" + "口杯袋\t把\t3\n" + "粥杯\t提\t2\n" + "包子辣油\t桶\t1.0\n" + "凉皮调料水\t桶\t1.0\n" + "发面料\t袋\t1\n" + "青椒南瓜馅\t袋\t2\n" + "白糖\t袋\t1\n" + "米线豆干\t份\t2\n" + "金辉\n" + "发面料\t袋\t1\n" + "凉皮调料水\t桶\t1.0\n" + "白糖\t袋\t1\n" + "青椒南瓜馅\t袋\t2\n" + "米线豆干\t份\t2\n" + "三爻\n" + "玉米粒罐头\t罐\t3\n" + "酸鱼汤底\t包\t3\n" + "番茄酱\t包\t1\n" + "五仁酱丁\t箱\t2\n" + "东古酱油\t桶\t1.0\n" + "天缘醋\t桶\t1.0\n" + "食用盐\t袋\t10\n" + "紫菜\t提\t1\n" + "750打包盒\t件\t2\n" + "一次性筷子\t件\t1\n" + "肉（粉蒸肉）\t件\t1\n" + "馍（粉蒸肉）\t件\t1\n" + "粉条（酸辣粉）\t份\t20\n" + "胡椒粉组合\t袋\t1\n" + "小米南瓜粥\t份\t8\n" + "大米绿豆\t份\t10\n" + "红豆玉米粥\t份\t6\n" + "八宝粥\t份\t12\n" + "凉皮调料水\t桶\t1.0\n" + "鸡架料包\t袋\t1\n" + "包子辣油\t桶\t1.0\n" + "青椒南瓜馅\t袋\t4\n" + "鸡蛋粉条\t袋\t3\n" + "卤鸡蛋\t袋\t8\n" + "花椒粉组合\t袋\t1\n" + "豆皮\t份\t1\n" + "米线\t份\t110\n" + "馄饨馅\t袋\t3\n" + "鲜肉馅\t袋\t6\n" + "白糖\t袋\t1\n" + "鸡精组合\t份\t1\n" + "酱肉馅\t份\t2\n" + "米线豆干\t份\t1\n" + "发面料\t袋\t1\n" + "外卖保温袋\t提\t3\n" + "海带（湿）\t袋\t4";

}