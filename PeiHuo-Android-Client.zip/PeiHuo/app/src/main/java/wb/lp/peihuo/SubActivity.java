package wb.lp.peihuo;

import android.content.Intent;
import android.os.Build;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.ListView;
import android.widget.TextView;

import androidx.activity.EdgeToEdge;
import androidx.annotation.RequiresApi;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

import com.google.gson.Gson;

import java.util.Comparator;
import java.util.List;
import java.util.Objects;
import java.util.stream.Collectors;

import wb.lp.peihuo.data.AllItem;
import wb.lp.peihuo.data.SubItem;

public class SubActivity extends AppCompatActivity {

    @RequiresApi(api = Build.VERSION_CODES.N)
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_sub);
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });
//        getWindow().addFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN);

        Objects.requireNonNull(getSupportActionBar()).hide();


        Intent intent = getIntent();
        String data = intent.getStringExtra("data");
        Gson gson = new Gson();
        AllItem allItem = gson.fromJson(data, AllItem.class);

        TextView tv = findViewById(R.id.m_t);
        tv.setText(allItem.getName());

        Button button = findViewById(R.id.ph_ok);
        button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
//                Toast.makeText(SubActivity.this, "配货完成", Toast.LENGTH_SHORT).show();
                setResult(RESULT_OK);
                finish();
            }
        });

        ListView viewById = findViewById(R.id.sub_listview);

        List<SubItem> collect = allItem.getSubItems().stream().sorted(new Comparator<SubItem>() {
            @Override
            public int compare(SubItem o1, SubItem o2) {
                return (int) (o1.getWeight() - o2.getWeight());
            }
        }).collect(Collectors.toList());
        viewById.setAdapter(new ArrayAdapter<>(this, android.R.layout.simple_list_item_1,collect ));

        viewById.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
//                Toast.makeText(SubActivity.this, collect.get(position).toString(), Toast.LENGTH_SHORT).show();
            }
        });

    }
}