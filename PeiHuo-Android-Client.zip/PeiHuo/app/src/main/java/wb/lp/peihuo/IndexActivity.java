package wb.lp.peihuo;

import android.content.Intent;
import android.os.Bundle;
import android.text.Editable;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

public class IndexActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_index);
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });

        EditText tv = findViewById(R.id.edit_text_url);
        Button bt = findViewById(R.id.url_button);
        bt.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                Editable text = tv.getText();
                if (text == null) {
                    Toast.makeText(IndexActivity.this, "请输入内容再继续", Toast.LENGTH_SHORT).show();
                    return;
                } else if (text.toString().isEmpty() || text.toString().isBlank()) {
                    Toast.makeText(IndexActivity.this, "请输入内容再继续", Toast.LENGTH_SHORT).show();
                    return;
                }

                HTTPUtils.BASE_URL = text.toString().trim(); //去除首尾空格

                Intent intent = new Intent();
                intent.setClass(IndexActivity.this, ConfirmActivity.class);
                startActivity(intent);
            }
        });


    }

}