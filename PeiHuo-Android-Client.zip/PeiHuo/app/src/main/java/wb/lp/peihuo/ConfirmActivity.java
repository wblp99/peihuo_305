package wb.lp.peihuo;

import static wb.lp.peihuo.HTTPUtils.BASE_URL;
import static wb.lp.peihuo.MainActivity.HT;
import static wb.lp.peihuo.MainActivity.JH;
import static wb.lp.peihuo.MainActivity.LM;
import static wb.lp.peihuo.MainActivity.QB;
import static wb.lp.peihuo.MainActivity.QJ;
import static wb.lp.peihuo.MainActivity.SY;
import static wb.lp.peihuo.MainActivity.WD;
import static wb.lp.peihuo.MainActivity.XQG;
import static wb.lp.peihuo.MainActivity.YH;

import android.content.Intent;
import android.os.Build;
import android.os.Bundle;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.ListView;

import androidx.activity.EdgeToEdge;
import androidx.annotation.RequiresApi;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.TypeReference;

import java.io.IOException;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;
import java.util.Map;
import java.util.Objects;
import java.util.function.BiConsumer;
import java.util.stream.Collectors;

import okhttp3.OkHttpClient;
import okhttp3.Request;
import okhttp3.Response;
import wb.lp.peihuo.data.SubItem;

public class ConfirmActivity extends AppCompatActivity {

    //    private  Map<String, AllItem> map ;
    private Map<String, Double> mapItemCount;

    int requestCode = 1;

    @RequiresApi(api = Build.VERSION_CODES.N)
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_confirm2);
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });
        Objects.requireNonNull(getSupportActionBar()).hide();

//        new Thread(new Runnable() {
//            @Override
//            public void run() {
//                OkHttpClient client = new OkHttpClient();
//                Request request = new Request.Builder()
//                        .url(BASE_URL + "/peihuoserver_war/getAllData")
//                        .build();
//                try {
//                    Response execute = client.newCall(request).execute();
//                    String json = execute.body().string();
//                    map  = JSON.parseObject(json, new TypeReference<Map<String, AllItem>>(){});
//                } catch (IOException e) {
//                    throw new RuntimeException(e);
//                }
//            }
//        }).start();

        new Thread(new Runnable() {
            @Override
            public void run() {
                OkHttpClient client = new OkHttpClient();
                Request request = new Request.Builder().url(BASE_URL + "/peihuoserver_war/getItemCount").build();
                try {
                    Response execute = client.newCall(request).execute();
                    String json = execute.body().string();
                    mapItemCount = JSON.parseObject(json, new TypeReference<Map<String, Double>>() {
                    });

                    //排序并展示
                    ArrayList<SubItem> subItems = new ArrayList<>();

                    mapItemCount.forEach(new BiConsumer<String, Double>() {
                        @Override
                        public void accept(String s, Double aDouble) {
                            SubItem subItem = new SubItem();
                            subItem.setMendian(s);
                            subItem.setCount(aDouble);
                            subItems.add(subItem);
                        }
                    });

                    List<SubItem> collect = subItems.stream().sorted(new Comparator<SubItem>() {
                        @Override
                        public int compare(SubItem o1, SubItem o2) {
                            return (int) (o1.getWeight() - o2.getWeight());
                        }
                    }).collect(Collectors.toList());

                    runOnUiThread(new Runnable() {
                        @Override
                        public void run() {

                            ListView listView = findViewById(R.id.hd_lv);
                            listView.setAdapter(new ArrayAdapter<>(ConfirmActivity.this, android.R.layout.simple_list_item_1, collect));

                            findViewById(R.id.hd_button1).setOnClickListener(new View.OnClickListener() {
                                @Override
                                public void onClick(View v) {

                                    Intent intent = new Intent();
                                    intent.setClass(ConfirmActivity.this, MainActivity.class);
                                    String surl = "/peihuoserver_war/getAllData";
                                    intent.putExtra("surl", surl);
                                    startActivity(intent);

                                }
                            });

                            findViewById(R.id.hd_button2).setOnClickListener(new View.OnClickListener() {
                                @Override
                                public void onClick(View v) {

                                    Intent intent = new Intent();
                                    intent.setClass(ConfirmActivity.this, MainActivity.class);
                                    String surl = "/peihuoserver_war/getLKData";
                                    intent.putExtra("surl", surl);
                                    startActivity(intent);

                                }
                            });
                        }
                    });

                } catch (IOException e) {
                    throw new RuntimeException(e);
                }
            }
        }).start();

//        Intent intent = getIntent();
//        String ysdata = intent.getStringExtra("ysdata");
//
//
//        Gson gson = new Gson();
//
//        List<String> strings = gson.fromJson(ysdata, List.class);
//
//        try {
//            loadData(strings);
//        } catch (Exception e) {
//            ConfirmActivity.this.finish();
//            Toast.makeText(ConfirmActivity.this, "配货数据格式不正确", Toast.LENGTH_LONG).show();
//        }

    }

//    double allCount = 0;

//    @RequiresApi(api = Build.VERSION_CODES.N)
//    private void loadData(List<String> strings) throws Exception {
//        String md = null;
//
//        //给每个记录加上门店信息
//        List<Item> items = new ArrayList<>();
//        for (String string : strings) {
//            if (switchData(string)) {
//
////                Log.d("LP", "loadData: " + string);
//
//                String[] split = string.split("\t");
//                Item item = new Item();
//                item.setMendian(md);
//                if (split.length != 3) {
//                    item.setName(split[0] + split[1]);
//                } else {
//                    item.setName(split[0]);
//                }
//
//                item.setDanwei(split[split.length - 2]);
//                item.setCount(Double.parseDouble(split[split.length - 1]));
//                items.add(item);
//
//                allCount += item.getCount();
//
//            } else {
//                md = string;
//            }
//        }
//
//
//        //核心数据
//
//        items.forEach(i -> {
//            String name = i.getName();
//            boolean b = map.containsKey(name);
//
//            if (b) {
//                AllItem allItem = map.get(name);
//                allItem.setCount(allItem.getCount() + i.getCount());
////                map.put(name, allItem);
//            } else {
//                AllItem allItem = new AllItem(i.getName(), i.getDanwei(), i.getCount());
//                allItem.setRequestCode(requestCode++);
//                map.put(name, allItem);
//            }
//
//            SubItem subItem = new SubItem();
//            subItem.setMendian(i.getMendian());
//            subItem.setCount(i.getCount());
//            subItem.setDanwei(i.getDanwei());
//
//            AllItem allItemX = map.get(name);
//            allItemX.getSubItems().add(subItem);
//
//
//            //按照门店统计数量
//            boolean b1 = mapItemCount.containsKey(i.getMendian());
//            if (b1) {
//                Double v = mapItemCount.get(i.getMendian());
//                mapItemCount.put(i.getMendian(), i.getCount() + v);
//            } else {
//                mapItemCount.put(i.getMendian(), i.getCount());
//            }
//
//        });
//
//
//        //排序并展示
//        ArrayList<SubItem> subItems = new ArrayList<>();
//
//        mapItemCount.forEach(new BiConsumer<String, Double>() {
//            @Override
//            public void accept(String s, Double aDouble) {
//                SubItem subItem = new SubItem();
//                subItem.setMendian(s);
//                subItem.setCount(aDouble);
//                subItems.add(subItem);
//            }
//        });
//
//        List<SubItem> collect = subItems.stream().sorted(new Comparator<SubItem>() {
//            @Override
//            public int compare(SubItem o1, SubItem o2) {
//                return (int) (o1.getWeight() - o2.getWeight());
//            }
//        }).collect(Collectors.toList());
//
//        ListView listView = findViewById(R.id.hd_lv);
//        listView.setAdapter(new ArrayAdapter<>(this, android.R.layout.simple_list_item_1, collect));
//
//        findViewById(R.id.hd_button).setOnClickListener(new View.OnClickListener() {
//            @Override
//            public void onClick(View v) {
//
//                Intent intent = new Intent();
//                intent.setClass(ConfirmActivity.this, MainActivity.class);
////                Gson gson = new Gson();
//                String json = JSON.toJSONString(map);
//                intent.putExtra("map", json);
////                intent.putExtra("allCount", ConfirmActivity.this.allCount);
//
//                startActivity(intent);
//
//            }
//        });
//    }


//@RequiresApi(api = Build.VERSION_CODES.N)
//private void loadData() throws Exception {
//    //排序并展示
//    ArrayList<SubItem> subItems = new ArrayList<>();
//
//    mapItemCount.forEach(new BiConsumer<String, Double>() {
//        @Override
//        public void accept(String s, Double aDouble) {
//            SubItem subItem = new SubItem();
//            subItem.setMendian(s);
//            subItem.setCount(aDouble);
//            subItems.add(subItem);
//        }
//    });
//
//    List<SubItem> collect = subItems.stream().sorted(new Comparator<SubItem>() {
//        @Override
//        public int compare(SubItem o1, SubItem o2) {
//            return (int) (o1.getWeight() - o2.getWeight());
//        }
//    }).collect(Collectors.toList());
//
//    ListView listView = findViewById(R.id.hd_lv);
//    listView.setAdapter(new ArrayAdapter<>(this, android.R.layout.simple_list_item_1, collect));
//
//    findViewById(R.id.hd_button).setOnClickListener(new View.OnClickListener() {
//        @Override
//        public void onClick(View v) {
//
//            Intent intent = new Intent();
//            intent.setClass(ConfirmActivity.this, MainActivity.class);

    /// /                Gson gson = new Gson();
    /// /            String json = JSON.toJSONString(map);
    /// /            intent.putExtra("map", json);
    /// /                intent.putExtra("allCount", ConfirmActivity.this.allCount);
//
//            startActivity(intent);
//
//        }
//    });
//}
    private boolean switchData(String str) {
        if (str.equals(SY)) return false;
        else if (str.equals(YH)) return false;
        else if (str.equals(WD)) return false;
        else if (str.equals(XQG)) return false;
        else if (str.equals(HT)) return false;
        else if (str.equals(LM)) return false;
        else if (str.equals(QB)) return false;
        else if (str.equals(JH)) return false;
        else if (str.equals(QJ)) return false;
        return true;
    }

}