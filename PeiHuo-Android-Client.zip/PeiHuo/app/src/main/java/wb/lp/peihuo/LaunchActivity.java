package wb.lp.peihuo;

import android.content.Intent;
import android.os.Bundle;
import android.text.Editable;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

import com.google.gson.Gson;

import java.util.ArrayList;
import java.util.List;
import java.util.Objects;

public class LaunchActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_launch);
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });

//        getWindow().addFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN);
        Objects.requireNonNull(getSupportActionBar()).hide();


        EditText editText = findViewById(R.id.edit_text_l);
        Button button = findViewById(R.id.m_button);

        button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Editable text = editText.getText();
                if (text == null) {
                    Toast.makeText(LaunchActivity.this, "请输入内容再继续", Toast.LENGTH_SHORT).show();
                    return;
                }else if(text.toString().isEmpty() || text.toString().isBlank()) {
                    Toast.makeText(LaunchActivity.this, "请输入内容再继续", Toast.LENGTH_SHORT).show();
                    return;
                }

                String s = text.toString().trim(); //去除首尾空格

                List<String> data = new ArrayList<>();
                String[] split = s.split("\n");
                for (String string : split) {
                    data.add(string); //拿到一行一行的数据
                }

                Intent intent = new Intent();
                intent.setClass(LaunchActivity.this, ConfirmActivity.class);
                Gson gson = new Gson();
                String json = gson.toJson(data);
                intent.putExtra("ysdata", json);

                startActivity(intent);
            }
        });
    }
}