package wb.lp.peihuo.data;

import java.util.ArrayList;
import java.util.List;
import java.util.Objects;

public class Item {

    public static List<String> lk = new ArrayList<>();

    static {
        lk.add("酱肉馅");
        lk.add("丸子");
        lk.add("鲜肉馅");
        lk.add("馄饨馅");
        lk.add("青椒南瓜馅");
        lk.add("鸡架料包");
        lk.add("黑鱼片");
        lk.add("鱼豆腐");
        lk.add("肥牛卷");
        lk.add("里脊肉丝");
        lk.add("豆皮");
    }

    // 每日汇总数量
    private double total;
    // 已配数量
    private double yesTotal;
    // 没配数量
    private double noTotal;
    //名称
    private String name;
    //数量
    private double count;
    //门店
    private String mendian;
    //单位
    private String danwei;
    //种类
    private String category;
    //排序
    private double paixu;
    //是否配了
    private boolean isPei;
    //是否是冷库
    private boolean isLengKu;

    public Item() {
    }

    public Item(int total, int yesTotal, int noTotal, String name, int count, String mendian, String danwei, String category, int paixu, boolean isPei, boolean isLengKu) {
        this.total = total;
        this.yesTotal = yesTotal;
        this.noTotal = noTotal;
        this.name = name;
        this.count = count;
        this.mendian = mendian;
        this.danwei = danwei;
        this.category = category;
        this.paixu = paixu;
        this.isPei = isPei;
        this.isLengKu = isLengKu;
    }

    public void setTotal(double total) {
        this.total = total;
    }

    public void setYesTotal(double yesTotal) {
        this.yesTotal = yesTotal;
    }

    public void setNoTotal(double noTotal) {
        this.noTotal = noTotal;
    }

    public void setName(String name) {
        this.name = name;
    }

    public void setCount(double count) {
        this.count = count;
    }

    public void setMendian(String mendian) {
        this.mendian = mendian;
    }

    public void setDanwei(String danwei) {
        this.danwei = danwei;
    }

    public void setCategory(String category) {
        this.category = category;
    }

    public void setPaixu(double paixu) {
        this.paixu = paixu;
    }

    public void setPei(boolean pei) {
        isPei = pei;
    }

    public void setLengKu(boolean lengKu) {
        isLengKu = lengKu;
    }

    public double getTotal() {
        return total;
    }

    public double getYesTotal() {
        return yesTotal;
    }

    public double getNoTotal() {
        return noTotal;
    }

    public String getName() {
        return name;
    }

    public double getCount() {
        return count;
    }

    public String getMendian() {
        return mendian;
    }

    public String getDanwei() {
        return danwei;
    }

    public String getCategory() {
        return category;
    }

    public double getPaixu() {
        return paixu;
    }

    public boolean isPei() {
        return isPei;
    }

    public boolean isLengKu() {
        return lk.contains(this.name);
    }

    @Override
    public String toString() {
        return "Item{" +
                "total=" + total +
                ", yesTotal=" + yesTotal +
                ", noTotal=" + noTotal +
                ", name='" + name + '\'' +
                ", count=" + count +
                ", mendian='" + mendian + '\'' +
                ", danwei='" + danwei + '\'' +
                ", category='" + category + '\'' +
                ", paixu=" + paixu +
                ", isPei=" + isPei +
                ", isLengKu=" + isLengKu() +
                '}';
    }

    @Override
    public boolean equals(Object o) {
        if (o == null || getClass() != o.getClass()) return false;
        Item item = (Item) o;
        return Objects.equals(category, item.category);
    }

    @Override
    public int hashCode() {
        return Objects.hashCode(category);
    }
}
