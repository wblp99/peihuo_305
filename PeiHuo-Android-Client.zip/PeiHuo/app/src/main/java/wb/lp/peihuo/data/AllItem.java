package wb.lp.peihuo.data;

import static wb.lp.peihuo.data.Item.lk;

import java.util.ArrayList;
import java.util.List;
import java.util.Objects;

import wb.lp.peihuo.R;

public class AllItem {

    public AllItem() {
    }

    public static final List<String> zhou = new ArrayList<>();

    static {
        zhou.add("小米南瓜粥");
        zhou.add("大米绿豆");
        zhou.add("红豆玉米粥");
        zhou.add("八宝粥");
        zhou.add("川味卤料");
        zhou.add("干木耳");
        zhou.add("鸡精组合");
        zhou.add("白糖");
        zhou.add("发面料");
        zhou.add("馄饨料葱油");
        zhou.add("花椒粉组合");
        zhou.add("胡椒粉组合");
        zhou.add("小熟芝麻");
        zhou.add("辣椒段");
        zhou.add("花椒粒");
        zhou.add("紫菜");


    }

    public static final List<String> daizi = new ArrayList<>();

    static {
        daizi.add("口杯袋");
        daizi.add("17背心袋");
        daizi.add("20背心袋");
        daizi.add("26背心袋");
        daizi.add("30背心袋");
//        daizi.add("外卖保温袋");
        daizi.add("85*95中垃圾袋");
        daizi.add("95*110大垃圾袋");
        daizi.add("小垃圾袋");


    }

    public void setDanwei(String danwei) {
        this.danwei = danwei;
    }

    public void setName(String name) {
        this.name = name;
    }

    public void setWeight(Integer weight) {
        this.weight = weight;
    }

//    public void setSubItems(List<SubItem> subItems) {
//        this.subItems = subItems;
//    }
//
    public static final List<String> dabaohe = new ArrayList<>();

    static {
        dabaohe.add("p4蘸料杯");
        dabaohe.add("一次性勺子");
        dabaohe.add("外卖蘸料碟（一次性调味碟）");
        dabaohe.add("450打包盒");
        dabaohe.add("750打包盒");
        dabaohe.add("1250打包盒");
        dabaohe.add("一次性泡茶杯");
        dabaohe.add("一次性筷子");
        dabaohe.add("抽纸（餐巾纸）");
        dabaohe.add("外卖保温袋");

    }

    public static final List<String> xiaodongxi = new ArrayList<>();

    static {
        xiaodongxi.add("一次性口罩");
        xiaodongxi.add("堂食勺子");
        xiaodongxi.add("洗洁精");
        xiaodongxi.add("吸管");
        xiaodongxi.add("外卖封口膜");
        xiaodongxi.add("打印纸 宽");
        xiaodongxi.add("打印纸 窄");
        xiaodongxi.add("一次性网帽");
        xiaodongxi.add("透明口罩（口屏）");
        xiaodongxi.add("笼盖子");
        xiaodongxi.add("小笼");
        xiaodongxi.add("红玫塑胶手套");
        xiaodongxi.add("一次性手套");
        xiaodongxi.add("45保鲜膜");
        xiaodongxi.add("粥杯");
    }

    public static final List<String> left = new ArrayList<>();

    static {
        left.add("外卖辣油");
        left.add("外卖醋包");
        left.add("玉米粒罐头");
        left.add("五仁酱丁");
        left.add("乌江榨菜");
        left.add("泡椒");
        left.add("粉带");


    }

    public static final List<String> layou = new ArrayList<>();

    static {
        layou.add("擀面皮辣油");
        layou.add("包子辣油");
        layou.add("米皮辣油");


    }

    public static final List<String> tiaoliao = new ArrayList<>();

    static {
        tiaoliao.add("酸鱼汤底");
        tiaoliao.add("酸菜");
        tiaoliao.add("天缘醋");
        tiaoliao.add("猪油");
        tiaoliao.add("食用纯碱");
        tiaoliao.add("食用盐");
        tiaoliao.add("香油");
        tiaoliao.add("醪糟");
        tiaoliao.add("东古酱油");
        tiaoliao.add("番茄酱");
    }

    public static final List<String> lengcang = new ArrayList<>();

    static {
        lengcang.add("米线");
        lengcang.add("粉条（酸辣粉）");
        lengcang.add("虾米");
        lengcang.add("海带（湿）");
        lengcang.add("米线豆干");
        lengcang.add("卤鸡蛋");
        lengcang.add("鸡蛋粉条");
    }

    private int requestCode;

    public int getRequestCode() {
        return requestCode;
    }

    public void setRequestCode(int requestCode) {
        this.requestCode = requestCode;
    }

    private double count;
    private String danwei;

    private String name;

    private Integer weight;

    public String getName() {
        return name;
    }

    private String color;

    private boolean isChecked;

    public boolean isChecked() {
        return isChecked;
    }

    public void setChecked(boolean checked) {
        isChecked = checked;
    }

    public String getColor() {
        return color;
    }

    public void setColor(String color) {
        this.color = color;
    }

    private List<SubItem> subItems = new ArrayList<>();

    public List<SubItem> getSubItems() {
        return subItems;
    }

    public AllItem(String name, String danwei, double count) {
        this.danwei = danwei;
        this.count = count;
        this.name = name;

        this.weight = getW();

    }

    public Integer getWeight() {
        return weight;
    }

    private Integer getW() {
        if (dabaohe.contains(name)) {
            this.color = String.valueOf(R.color.purple_2);
            return 100;
        }
        if (zhou.contains(name)) {
            this.color = String.valueOf(R.color.purple_3);
            return 99;
        }
        if (tiaoliao.contains(name)){
            this.color = String.valueOf(R.color.purple_4);
            return 98;
        }
        if (daizi.contains(name)){
            this.color = String.valueOf(R.color.purple_5);
            return 97;
        }
        if (xiaodongxi.contains(name)){
            this.color = String.valueOf(R.color.purple_6);
            return 96;
        }
        if (layou.contains(name)){
            this.color = String.valueOf(R.color.purple_7);
            return 95;
        }
        if (left.contains(name)){
            this.color = String.valueOf(R.color.purple_8);
            return 94;
        }
        if (lengcang.contains(name)){
            this.color = String.valueOf(R.color.purple_9);
            return 93;
        }
        if (lk.contains(name)){
            this.color = String.valueOf(R.color.purple_1);
            return 92;
        }

        this.color = String.valueOf(R.color.purple_10);
        return 0;
    }

    public String getDanwei() {
        return danwei;
    }

    public double getCount() {
        return count;
    }

    public void setCount(double count) {
        this.count = count;
    }


    @Override
    public boolean equals(Object o) {
        if (o == null || getClass() != o.getClass()) return false;
        AllItem allItem = (AllItem) o;
        return Objects.equals(weight, allItem.weight);
    }

    @Override
    public int hashCode() {
        return Objects.hashCode(weight);
    }

    @Override
    public String toString() {
        return name + "\t" + count + "\t" + danwei;

    }
}
